#include <ncurses.h>

void draw_cube(int start_x, int start_y) {
    // Desenhar as linhas verticais
    mvprintw(start_y, start_x, "  ______");
    mvprintw(start_y + 1, start_x, " /     /|");
    mvprintw(start_y + 2, start_x, "/_____/ |");
    mvprintw(start_y + 3, start_x, "|_____| |");
    mvprintw(start_y + 4, start_x, "| (o) | |");
    mvprintw(start_y + 5, start_x, "|_____|/ ");
}

int main() {
    initscr();            // Inicia o modo ncurses
    cbreak();             // Desativa o buffering de linha
    noecho();             // Desativa a exibição dos caracteres digitados
    curs_set(FALSE);      // Oculta o cursor

    int height, width;
    getmaxyx(stdscr, height, width);

    mvprintw(height / 2 - 2, width / 2 - 5, "PIPELINE");
    draw_cube(width / 2 - 5, height / 2);

    mvprintw(height / 2 + 7, width / 2 - 5, "[Iniciar]");

    refresh();            // Atualiza a tela com o conteúdo do buffer
    getch();              // Espera por uma entrada do usuário

    endwin();             // Encerra o modo ncurses

    return 0;
}
