#include <ncurses.h>
#include <stdlib.h>

// Função do menu usando ncurses
char menu(WINDOW *menuwin) {
    box(menuwin, 0, 0);
    keypad(menuwin, TRUE); // Habilita captura de teclas especiais
    wrefresh(menuwin);

    // Desenhando o cabeçalho
    mvwprintw(menuwin, 1, 2, "                                         ----                   ");
    mvwprintw(menuwin, 2, 2, "                          PIPELINE      |( )|                   ");
    mvwprintw(menuwin, 3, 2, "                                        ----                    ");

   // mvwprintw(menuwin, 5, 2, "\tPC: %i Instrução: %s Estado: %i", 0, "NOP", 0);  // Valores de exemplo
    mvwprintw(menuwin, 7, 2, "\tInstrução em Assembly:");
    mvwprintw(menuwin, 9, 2, "\t(r) (RUN) Executar todo o arquivo");
    mvwprintw(menuwin, 10, 2, "\t(e) (STEP) Executar uma linha");
    mvwprintw(menuwin, 11, 2, "\t(b) (BACK) Voltar uma instrução");
    mvwprintw(menuwin, 12, 2, "\t(v) Ver Estado");
    mvwprintw(menuwin, 13, 2, "\t(a) Ver Instrução Atual");
    mvwprintw(menuwin, 14, 2, "\t(i) Ver Registradores");
    mvwprintw(menuwin, 15, 2, "\t(d) Ver Memória de Dados");
    mvwprintw(menuwin, 16, 2, "\t(i) Ver Todas as Instruções");
    mvwprintw(menuwin, 17, 2, "\t(s) Ver Sinais");
    mvwprintw(menuwin, 18, 2, "\t(t) Ver Variáveis");
    mvwprintw(menuwin, 19, 2, "\t(c) Ver Registradores Temporários");
    //mvwprintw(menuwin, 16, 2, "\t(s) Salvar .asm");
   // mvwprintw(menuwin, 17, 2, "\t(t) Salvar .dat");
    mvwprintw(menuwin, 20, 2, "\t(x) Sair");
    mvwprintw(menuwin, 21, 2, "****************************************************************");
    mvwprintw(menuwin, 22, 2, "\tSelecione: ");

    wrefresh(menuwin);
    char p = wgetch(menuwin);  // Captura a entrada do usuário
    return p;
}

// Função para exibir a janela dos registradores
void exibir_registradores(WINDOW *regwin) {
    box(regwin, 0, 0);
    mvwprintw(regwin, 1, 1, "Banco de Registradores");
    // Adicione aqui a lógica para exibir os registradores
    wrefresh(regwin);
}

// Função para exibir a janela da memória
void exibir_memoria(WINDOW *memwin) {
    box(memwin, 0, 0);
    mvwprintw(memwin, 1, 1, "Memória");
    // Adicione aqui a lógica para exibir a memória
    wrefresh(memwin);
}
void exibir_inst(WINDOW *instmem) {
    box(instmem, 0, 0);
    mvwprintw(instmem, 1, 1, "Memória de Instruções");
    // Adicione aqui a lógica para exibir a memória
    wrefresh(instmem);
}

int main() {
    initscr();            // Inicia o modo ncurses
    cbreak();             // Desativa o buffering de linha
    noecho();             // Desativa a exibição dos caracteres digitados
    curs_set(FALSE);      // Oculta o cursor

    int height, width;
    getmaxyx(stdscr, height, width);

    WINDOW *startwin = newwin(20, 50, (height / 2) - 10, (width / 2) - 25);
    box(startwin, 0, 0);
    keypad(startwin, TRUE); // Habilita captura de teclas especiais
    refresh();
    wrefresh(startwin);

    mvwprintw(startwin, 3, 15, "PIPELINE");
  	mvwprintw(startwin, 6, 20, "  ______");
  	mvwprintw(startwin, 7, 20, " /     /|");
  	mvwprintw(startwin, 8, 20, "/_____/ |");
  	mvwprintw(startwin, 9, 20, "|_____| |");
  	mvwprintw(startwin, 10, 20, "| (o) | |");
  	mvwprintw(startwin, 11, 20, "|_____|/ ");
  	mvwprintw(startwin, 15, 15, "[Pressione ENTER para Iniciar]");

    wrefresh(startwin);
        int ch = wgetch(startwin);
        if (ch == '\n') {  // Verifica se o usuário pressionou Enter
            delwin(startwin); // Deleta a janela inicial

            // Criar janelas fixas para o menu, registradores e memória
            WINDOW *menuwin = newwin(22, 62, (height / 2) - 11, (width / 2) - 31);
            WINDOW *regwin = newwin(10, 30, 1, 1);
            WINDOW *memwin = newwin(10, 30, 12, 1);
            WINDOW *instmem = newwin(10, 120, 44, 30);

                exibir_registradores(regwin);
                exibir_memoria(memwin);
                exibir_inst(instmem);
                char p = menu(menuwin);
                if (p == 'x') {
                    //break;  // Encerra o programa ao pressionar 'x'
                }

            // Deleta as janelas antes de encerrar
            delwin(menuwin);
            delwin(regwin);
            delwin(memwin);
            delwin(instmem);
        }
    endwin();             // Encerra o modo ncurses
    return 0;
}
