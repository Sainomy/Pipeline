#include <stdio.h>
#include <stdlib.h>
#include "mips.h"
//#include <ncurses.h>

int main(){
  int *pc = (int *)malloc(sizeof(int));
  *pc = 0;
  
  struct instrucao *regmem = (struct instrucao*)malloc(256*sizeof(struct instrucao));
  
  int *registradores = iniciarRegi();
  
  int *memD = iniciarMemD();

  struct controle *sinais = iniciarConrole();

  struct regiS *regS1 = inciarRegiS();
  struct regiS *regS2 = inciarRegiS();
  
  struct variaveis *var = inciarVariaveis();
  
  int op = 0;
  
  //////////
  carregarMemoria("t.txt", regmem);
  do{
    if(op!=1){ 
        op=menu(sinais/*, mem,*/, pc/*, regitemp, registrador, pilha*/);
        if(op == 3){
          break;
        }
    }

  //////
 
  *pc = var->muxDVI;
  
  memReg(regmem, *pc);

  *regS2->bi_di->inst = regmem[*pc];
  regS2->bi_di->pc = *pc +1;
  
  //////////BI/DI
  
  UC(sinais, regS1->bi_di);

  BancoRegistradores(registradores, regS1->bi_di->inst->b11_9, regS1->bi_di->inst->b8_6, regS1->mem_er->muxRegDst,  var->muxMemReg, var->saida1, var->saida2, regS1->mem_er->sinais->EscReg);
  
  regS2->di_ex->inst->b5_3 = regmem->b5_3;
  regS2->di_ex->inst->b5_0 = regmem->b5_0;
  regS2->di_ex->sinais = sinais;
  //////////DI/EX 

  
  if(regS1->di_ex->sinais->RegDst == 0){
    var->muxULA = regS1->bi_di->inst->b8_6;
  }
  else{
    var->muxULA = regS1->bi_di->inst->b5_3;
  }

  if(regS1->di_ex->sinais->ULAFonte == 1){
    var->muxULA = regS1->bi_di->inst->b5_0;
  }
  else{
    var->muxULA = *var->saida2;
  }

  ula(*var->saida1, var->muxULA, var->ULA , var->flag, regS1->di_ex->sinais->ULAOp);
  
    regS2->ex_mem->sinais = regS1->di_ex->sinais;
  
  //////////EX/MEM
  
  memDados(memD, *var->ULA, *var->saida2, regS1->ex_mem->sinais->EscMem, var->saidaMem);

  if((*var->flag + regS1->ex_mem->sinais->DVC) == 2){
    var->muxDVC = 1;
  }
  if(var->muxDVC == 1){
    var->muxDVC = *pc + 1 + regS1->bi_di->inst->b5_0;
  }
  else{
    var->muxDVC = *pc + 1;
  }

  if(regS1->ex_mem->sinais->DVI == 0){
    var->muxDVI = var->muxDVC;
  }
  else{
    var->muxDVI = /* complemeta com pc + 1 */ regS1->bi_di->inst->b0_6;
  }
  
    regS2->mem_er->sinais = regS1->ex_mem->sinais;
  //////////MEM/ER

  if(regS1->mem_er->sinais->MemParaReg == 1){
    var->muxMemReg = regS1->mem_er->muxRegDst;
  }
  else{
    var->muxMemReg = *var->saidaMem;
  }
  ////////////////
  *regS1->bi_di =  *regS2->bi_di;
  *regS1->di_ex = *regS2->di_ex;
  *regS1->ex_mem = *regS2->ex_mem;
  *regS1->mem_er = *regS2->mem_er;
  
  //////////
    
  }while(1);

return 0;
}