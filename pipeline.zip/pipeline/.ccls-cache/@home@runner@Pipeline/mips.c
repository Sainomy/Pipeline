#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "mips.h"


//funcoes principais

struct instrucao memReg(struct instrucao *mem, int pc){
  return mem[pc];
}

int memDados(int *memD, int endereco, int dado, int EscMem, int *saida){
 if(EscMem == 0){
   return memD[endereco]; 
 } 
  else{
   memD[endereco] = dado;
   return *memD;
  }
}

void ula(int valor1, int valor2, int *saida, int *flag, int ULAop){

switch(ULAop){
  
  case 0:
  if(valor1 + valor2 > 127 || valor1 + valor2 < -128){
    *flag = 1;
  }
  *saida = valor1 + valor2;
  break;
  
  case 2:
  if(valor1 - valor2 > 127 || valor1 - valor2 < -128){
    *flag = 1;
  }
  *saida = valor1 - valor2;
  break;
  
  case 4:
  if((valor1 & valor2) > 127 || (valor1 & valor2) < -128){
   *flag = 1;
  }
  *saida = valor1 & valor2;
  break;
  
  case 5:
  if((valor1 | valor2) > 127 || (valor1 | valor2) < -128){
    *flag = 1;
  }
  *saida = valor1 | valor2;
  break;

  case 6:
  if(valor1 == valor2){
    *flag = 1;
    *saida = 0;
  }
  break;
  
  }
}

void BancoRegistradores(int *registradores, int ReadEnd1, int ReadEnd2, int WriteEnd, int dado, int *saida1, int *saida2, int EscReg){
  if(EscReg == 0){
    *saida1 = registradores[ReadEnd1];
    *saida2 = registradores[ReadEnd2];
  }
  else{
    registradores[WriteEnd] = dado;
  }
}

struct controle *UC(struct controle *sinais, struct regiBI_ID *bits){
  switch(bits->inst->opcode){
    case 0:
      sinais->RegDst = 0;
      sinais->ULAOp = bits->inst->funct;
      sinais->ULAFonte = 0;
      sinais->DVC = 0;
      sinais->DVI = 0;
      sinais->EscMem = 0;
      sinais->EscReg = 1;
      sinais->MemParaReg = 1;
      break;
    
    case 2:
      sinais->RegDst = 0;
      sinais->ULAOp = 0;
      sinais->ULAFonte = 0;
      sinais->DVC = 0;
      sinais->DVI = 1;
      sinais->EscMem = 0;
      sinais->EscReg = 0;
      sinais->MemParaReg = 0;
      break;
    
    case 4:
      sinais->RegDst = 0;
      sinais->ULAOp = 0;
      sinais->ULAFonte = 1;
      sinais->DVC = 0;
      sinais->DVI = 0;
      sinais->EscMem = 0;
      sinais->EscReg = 1;
      sinais->MemParaReg = 1;
      break;
    
    case 8:
      sinais->RegDst = 0;
      sinais->ULAOp = 1;
      sinais->ULAFonte = 0;
      sinais->DVC = 1;
      sinais->DVI = 0;
      sinais->EscMem = 0;
      sinais->EscReg = 0;
      sinais->MemParaReg = 0;
      break;
    
    case 11:
      sinais->RegDst = 0;
      sinais->ULAOp = 0;
      sinais->ULAFonte = 1;
      sinais->DVC = 0;
      sinais->DVI = 0;
      sinais->EscMem = 0;
      sinais->EscReg = 1;
      sinais->MemParaReg = 0;
      break;
    
    case 15:
      sinais->RegDst = 0;
      sinais->ULAOp = 0;
      sinais->ULAFonte = 0;
      sinais->DVC = 0;
      sinais->DVI = 0;
      sinais->EscMem = 1;
      sinais->EscReg = 0;
      sinais->MemParaReg = 1;
      break;
  }
}

//funcoes de apoio

void carregarMemoria(char *nomeArquivo, struct instrucao *mem){
  char op[5];
  int i=0;
  FILE *arquivo;
  arquivo = fopen(nomeArquivo, "r");

  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo.\n");
    return;
  }

  while (fscanf(arquivo, "%16s", mem[i].instrucao) != EOF && i < 256) {
    //strncpy(op, mem[i].instrucao, 4);
    //mem[i].opcode=bi_dec(op);
    decodificarOpcode(mem, i);
    i++;
  }
  fclose(arquivo);
}

int bi_dec(char *bin){
  int i=strlen(bin);
  int value,deci=0,k=0;
  for(int j=i;j>0;j--){
    if(bin[j-1]=='0'){
      value=0;
    }
    else{
      value=1;
    }
  deci=deci+value*(pow(2,k));
  k++;
  }
  return(deci);
}

void decodificarOpcode(struct instrucao *mem, int n_instrucoes){
  
  char b11_9[4];
  char b8_6[4];
  char b5_3[4];
  char b5_0[7];
  char b0_6[8];
  char op[5];
  char funct[4];
  
  for(int i=0;i<3;i++){
    b11_9[i]=mem[n_instrucoes].instrucao[i+4];
    b8_6[i]=mem[n_instrucoes].instrucao[i+7];
    b5_3[i]=mem[n_instrucoes].instrucao[i+10];
    funct[i]=mem[n_instrucoes].instrucao[i+13];
    op[i]=mem[n_instrucoes].instrucao[i];
  }
  op[3]=mem[n_instrucoes].instrucao[3];
  
  for(int i=0;i<7;i++){
     b5_0[i]=mem[n_instrucoes].instrucao[i+10];
     b0_6[i]=mem[n_instrucoes].instrucao[i+9];
  }
  b0_6[6]=mem[n_instrucoes].instrucao[15];
  
  
  b11_9[3] = '\0';
  b8_6[3] = '\0';
  b5_3[3] = '\0';
  b5_0[6] = '\0';
  b0_6[7] = '\0';
  op[4] = '\0';
  funct[3] = '\0';
  
  mem[n_instrucoes].b0_6=bi_dec(b0_6);
  mem[n_instrucoes].b5_0=bi_dec(b5_0);
  mem[n_instrucoes].b8_6=bi_dec(b8_6);
  mem[n_instrucoes].b5_3=bi_dec(b5_3);
  mem[n_instrucoes].b11_9=bi_dec(b11_9);
  mem[n_instrucoes].opcode=bi_dec(op);
  mem[n_instrucoes].funct=bi_dec(funct);
  
}

struct controle * iniciarConrole(){
  struct controle *aux=(struct controle *)malloc(sizeof(struct controle));
  //aux->louD=0;
  aux->EscMem=0;
  //aux->IREsc=0;
  aux->RegDst=0;
  //aux->EscReg=0;
  aux->MemParaReg=0;
  aux->ULAFonte=0;
  //aux->ULAFonteDown=0;
  aux->ULAOp=0;

  //aux->branch=0;
  //aux->PCEsc=0;
  //aux->FontePC=0;
  return aux;
}

int menu(struct controle *sinais/*, dados *mem*/, int *PC/*, registradorapoio *regitemp, int *registrador, Pilha *pilha*/){

  char p;

  printf("\n================================================================\n");
  printf("\t\t\t    MULTICICLO\n");
  printf("================================================================\n");
 /* printf("\t    PC: %i Instrução: %s Estado: %i\n\n", *PC, mem[*PC].instrucoes.instrucao, sinais->estado_atual);
  printf("\t    Instrução em Assembly: ");
  if(mem->d_i==1){
    traduzirInstrucao(mem, PC);
  }
  */
  printf("\n");
  printf("\t\t (r) (RUN) Executar todo o arquivo    \n");
  printf("\t\t (e) (STEP) Executar uma linha        \n");
  printf("\t\t (b) (BACK) Voltar uma instrução      \n");
  printf("\t\t (v) Ver Registradores               \n");
  printf("\t\t (a) Ver Instrução Atual             \n");
  printf("\t\t (i) Ver Todas as Instruções         \n");
  printf("\t\t (d) Ver Memória de Dados            \n");
  printf("\t\t (s) Salvar .asm                     \n");
  printf("\t\t (t) Salvar .dat                     \n");
  printf("\t\t (c) Carregar .dat                   \n");
  printf("\t\t (x) Sair                            \n");
  printf("================================================================\n");
  printf("\t\tSelecione: ");
  scanf("%s",&p);

  switch(p){
    case 'r':
      return 1;
      break;
    case 'e':
      return 0;
      break;
    /*
    case 'b':
    if (!isEmpty(pilha)) {
      fback(sinais, mem, PC, regitemp, registrador, pilha, 1);
    }
    else {
      printf("Nenhuma instrução para voltar\n");
    }
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 'v':
    //  verReg(registrador);struct nodo_Pilha * criaNodo(){
    verReg(registrador, regitemp, sinais);

      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 'a':
    verInstrucaoAtual(mem, *PC);
    //  verinstrucoes(mem,count,0, n_instrucoes);
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 'i':
    verInstrucoesTodas(mem, *PC);
      //verinstrucoes(mem, count,1, n_instrucoes);
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 'd':
      vermemoriadados(mem, PC);
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 's':
      salvarAsm(mem);
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 't':
      salvarDados(mem);
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    case 'c':
    //  carregarDados(memoria2);
      return menu(sinais, mem, PC, regitemp, registrador, pilha);
      break;
    */
    case 'x':
      printf("Programa finalizado\n");
      return 3;
      break;
    default:
      printf("Opção inválida\n");
      return menu(sinais/*, mem,*/, PC /*, regitemp, registrador, pilha*/);
      break;
    
  }
  return 3;
}

int * iniciarRegi(){

  int *aux=(int *)malloc(8*sizeof(int));  
  for(int i=0; i<8; i++){
    aux[i] = 0;
  }
  return aux;

};

int * iniciarMemD(){

  int *aux=(int *)malloc(256*sizeof(int));  
  for(int i=0; i<256; i++){
    aux[i] = 0;
  }
  return aux;

};

struct regiS * inciarRegiS(){

  struct regiS *aux=(struct regiS *)malloc(sizeof(struct regiS));
  aux->bi_di = (struct regiBI_ID *)malloc(sizeof(struct regiBI_ID));
  aux->di_ex = (struct regiDI_EX *)malloc(sizeof(struct regiDI_EX));
  aux->ex_mem = (struct regiEX_MEM *)malloc(sizeof(struct regiEX_MEM));
  aux->mem_er = (struct regiMEM_ER *)malloc(sizeof(struct regiMEM_ER));
  
  aux->bi_di->inst = (struct instrucao *)malloc(sizeof(struct instrucao));
  aux->di_ex->inst = (struct instrucao *)malloc(sizeof(struct instrucao));
  aux->ex_mem->inst = (struct instrucao *)malloc(sizeof(struct instrucao));
  aux->mem_er->inst = (struct instrucao *)malloc(sizeof(struct instrucao));
  
  aux->di_ex->sinais = (struct controle *)malloc(sizeof(struct controle));
  aux->ex_mem->sinais = (struct controle *)malloc(sizeof(struct controle));
  aux->mem_er->sinais = (struct controle *)malloc(sizeof(struct controle));

  aux->bi_di->var = inciarVariaveis();
  aux->di_ex->var = inciarVariaveis();
  aux->ex_mem->var = inciarVariaveis();
  aux->mem_er->var = inciarVariaveis();
  
  return aux;
};

struct variaveis * inciarVariaveis(){

      struct variaveis *aux = (struct variaveis *)malloc(sizeof(struct variaveis));
      aux->flag=(int *)malloc(sizeof(int));
      *aux->flag = 0;
      aux->saida1 = (int *)malloc(sizeof(int));
      *aux->saida1 = 0;
      aux->saida2 = (int *)malloc(sizeof(int));
      *aux->saida1 = 0;
      aux->ULA = (int *)malloc(sizeof(int));
      *aux->ULA = 0;
      aux->saidaMem = (int *)malloc(sizeof(int)); 
      *aux->saidaMem = 0;
      aux->muxDVC = 0;
      aux->muxDVI = 0;
      aux->muxloaD = 0;
      aux->muxRegDst = 0;
      aux->muxMemReg = 0;
      aux->muxULA = 0;
      return aux;
  
};